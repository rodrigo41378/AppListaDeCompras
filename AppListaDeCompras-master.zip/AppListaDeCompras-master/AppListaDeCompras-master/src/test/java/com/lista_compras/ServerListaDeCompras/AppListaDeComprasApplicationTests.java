package com.lista_compras.ServerListaDeCompras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppListaDeComprasApplicationTests {

	@Test
	void contextLoads() {
	}

}
