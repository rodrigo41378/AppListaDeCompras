package com.lista_compras.ServerListaDeCompras;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerListaDeComprasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerListaDeComprasApplication.class, args);
	}

}
